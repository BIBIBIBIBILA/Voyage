# Centralized script-driven message tables (shared by engine/player)

KEY_PICKUP_MESSAGES = {
    "k14": "You've got the ticket—you're cleared to pass the gate.",
    "k9":  "Student ID obtained. You can head to your dorm now.",
    "k4":  "Key acquired. You can go to the Student Center and chat with classmates.",
    "k5":  "Your classmate said you can now pick up a key at the Student Center. Time to head to the Teaching Building.",
    "k6":  "You’ve obtained the Magic Key. You can now collect your S1 transcript at the Student Center.",
    "k3":  "Key obtained. You can now attend the Tutorial in the Teaching Building.",
    "k7":  "Looks like a dorm room key—you can visit other rooms now.",
    "k8":  "Looks like a dorm room key—you can visit other rooms now.",
    "k10": "This should be the balcony key—let’s try the rooftop/balcony.",
    "k1":  "This is a Sydney jacaranda—a magical key to the Harry Potter Building.",
}

DOOR_LOCK_MESSAGES = {
    "d14": "Gate locked. A ticket (k14) is required.",
    "d9":  "Dorm door locked. A Student ID (k9) is required.",
    "d4":  "This door needs the corresponding key.",
    "d5":  "This door needs the corresponding key.",
    "d6":  "This door's key is a crystallization of magic.",
    "d7":  "This door needs the corresponding key.",
    "d8":  "This door needs the corresponding key.",
    "d10": "This door is currently closed; rumor says the key is in another tall building.",
    "d2":  "This is the Library. A library companion card (k2) is required.",
    "d3":  "This is the Teaching Building. Entry denied until you’re verified as a USYD student.",
    "d1":  "This is the Harry Potter Building. You’ll need the jacaranda (k1) to open it.",
}

DOOR_PASS_MESSAGES = {
    "d14": "You’ve passed through the gate."
}
